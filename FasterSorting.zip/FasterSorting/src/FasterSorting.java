
import java.util.*;
class MergeRec{

public static void Merge(int [] numbers, int left, int mid, int right)
{
int [] tmp = new int[25];
int i, Left_side, elements, pos;
  
Left_side = (mid - 1);
pos = left;
elements = (right - left + 1);
  
while ((left <= Left_side) && (mid <= right))
{
if (numbers[left] <= numbers[mid])
tmp[pos++] = numbers[left++];
else
tmp[pos++] = numbers[mid++];
}
  
while (left <= Left_side)
tmp[pos++] = numbers[left++];

while (mid <= right)
tmp[pos++] = numbers[mid++];

for (i = 0; i < elements; i++)
{
numbers[right] = tmp[right];
right--;
}
}

static public void MergeSort_Recursive(int [] numbers, int left, int right)
{
int mid;
  
if (right > left)
{
mid = (right + left) / 2;
MergeSort_Recursive(numbers, left, mid);
MergeSort_Recursive(numbers, (mid + 1), right);
  
Merge(numbers, left, (mid+1), right);
}
}
public static void main(String[] args)
{
int n;
System.out.println("Enter number of elements in the array");
@SuppressWarnings("resource")
Scanner s = new Scanner(System.in);
n=s.nextInt();
int[] input = new int[n];
for(int i=0;i<n;i++)
{
input[i]=s.nextInt();
}
MergeSort_Recursive(input, 0, n-1);
for (int i = 0; i < n; i++)
System.out.print(input[i]+" ");

}
}
