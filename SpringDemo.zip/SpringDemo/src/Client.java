   

 import org.springframework.context.ApplicationContext;
 import org.springframework.context.support.ClassPathXmlApplicationContext;
 
	
	public class Client {
		
	public static  void main (String[]args) {
		
		Employee e = new Employee();
		
	     
		e.setEid(201);
		e.setEname ("Sagar Chadderwala");
		e.setEsalary(70000);
		
		
		
		System.out.println(e);
		
		
		//Inversion of Control (IOC)
		
		
		//1. add jar file for spring core
		//2. configure java object in an XML file
		//3. use Spring IOC container eg. Beanfactory or applicationContext to get the object cobstructed  by them
		
 ApplicationContext context = new ClassPathXmlApplicationContext ("EmployeeBean.xml");
	
		Employee e1 = (Employee)context.getBean("emp1");
		Employee e2 = (Employee)context.getBean("emp2");
	
		
		System.out.println("------------Spring IOC in Action-----------");
		
		System.out.println(e1);
		System.out.println(e2);
		
		
	}
	
}
